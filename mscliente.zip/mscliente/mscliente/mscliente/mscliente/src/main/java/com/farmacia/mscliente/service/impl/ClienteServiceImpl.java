package com.farmacia.mscliente.service.impl;
import com.farmacia.mscliente.dto.*;
import com.farmacia.mscliente.exceptions.*;
import com.farmacia.mscliente.model.Cliente;
import com.farmacia.mscliente.repository.ClienteRepository;
import com.farmacia.mscliente.service.ClienteService;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class ClienteServiceImpl implements ClienteService {
    private final ClienteRepository repository;

    @Override
    public ClienteResponseDTO crear(ClienteRequestDTO dto) {

        if (repository.existsByEmail(dto.getEmail())) {

            throw new EmailDuplicadoException(
                    "El email ya está registrado"
            );
        }

        // DTO -> ENTITY
        Cliente cliente = new Cliente();

        cliente.setNombre(dto.getNombre());
        cliente.setEmail(dto.getEmail());
        cliente.setTelefono(dto.getTelefono());

        Cliente guardado = repository.save(cliente);

        return convertirDTO(guardado);
    }

    @Override
    @Transactional(readOnly = true)
    public ClienteResponseDTO obtenerPorId(Long id) {

        Cliente cliente = repository.findById(id)
                .orElseThrow(() ->
                        new RecursoNoEncontradoException(
                                "Cliente no encontrado"
                        ));

        return convertirDTO(cliente);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ClienteResponseDTO> listar() {

        return repository.findAll()
                .stream()
                .map(this::convertirDTO)
                .toList();
    }

    @Override
    public ClienteResponseDTO actualizar(
            Long id,
            ClienteRequestDTO dto
    ) {

        Cliente cliente = repository.findById(id)
                .orElseThrow(() ->
                        new RecursoNoEncontradoException(
                                "Cliente no encontrado"
                        ));

        if (!cliente.getEmail().equals(dto.getEmail())
                && repository.existsByEmail(dto.getEmail())) {

            throw new EmailDuplicadoException(
                    "El email ya está en uso"
            );
        }

        cliente.setNombre(dto.getNombre());
        cliente.setEmail(dto.getEmail());
        cliente.setTelefono(dto.getTelefono());

        Cliente actualizado = repository.save(cliente);

        return convertirDTO(actualizado);
    }

    @Override
    public void eliminar(Long id) {

        if (!repository.existsById(id)) {

            throw new RecursoNoEncontradoException(
                    "Cliente no encontrado"
            );
        }

        repository.deleteById(id);
    }

    // =========================
    // MAPPER MANUAL
    // =========================

    private ClienteResponseDTO convertirDTO(Cliente cliente) {

        ClienteResponseDTO dto = new ClienteResponseDTO();

        dto.setId(cliente.getId());
        dto.setNombre(cliente.getNombre());
        dto.setEmail(cliente.getEmail());
        dto.setTelefono(cliente.getTelefono());

        return dto;
    }
}
