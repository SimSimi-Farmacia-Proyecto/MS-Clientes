package com.farmacia.mscliente.config;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeignClienteConfig {
}
