package com.farmacia.mscliente.repository;
import com.farmacia.mscliente.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long >{
    boolean existsByEmail(String email);

}
